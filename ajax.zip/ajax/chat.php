<?php

require '../core/init3.php';
if (isset($_POST['method']) === true && empty($_POST['method']) === false){

	$chat    = new chat();
	$method  = trim($_POST['method']);

	if($method === 'fetch'){
	
	$messages = $chat->fetchMessages();
	
	if(empty($messages) === true){
		echo 'There are currently no messages in the Chat';
	}else{
		foreach($messages as $message){
		?>
		<div class = "message">
		<a href ="#"><?php echo $message['username']; ?></a> says:
		<p><?php echo nl2br($message['message']); ?></p>
		</div>
		
		<?php
		}
	}
	}else if ($method === 'throw' && isset($_POST['message']) === true){
	$message = trim($_POST['message']);
	if(empty($message) === false){
	//The user_id is what allows the chat box to access each user that is logged in by their "SESSION"
	$chat->throwMessage($_SESSION['user_id'], $message);
	
	}
	}
}

?>