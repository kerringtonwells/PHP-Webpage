<nav>
        
            <ul>
       
                <li><a href="index.php">Home</a></li>
              
                <li><a href="downloads.php">Downloads</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="contact.php">Contact us</a></li>
                
            </ul>
        </nav>