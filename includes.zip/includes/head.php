<head>
    <title>Kerringtonwells.com</title>
    <meta charset="UTF-8">
    <link rel="stylesheet"  type = "text/css" href="css/screen.css">
    <link rel="shortcut icon" href="/images/favicon.ico" type="image/x-icon" />
</head>