<?php
session_start();
$_SESSION['user'] = (isset($_GET['user']) === true) ? (int)$_GET['user'] : 0;

?>





	<div class = "chat">
	<div class = "messages">
	<div class = "message">
	<a href = "#">Kerrington </a>Says:

	<p>The message will be displayed here</p>
	</div>
	</div>
	<textarea class = "entry" placeholder="Type here and hit Return. Use shift + Return for a new line"></textarea>
	</div>
	
	<script src = "http://code.jquery.com/jquery-1.9.1.min.js"></script>	
	<script src = "js/chat.js"></script>	
