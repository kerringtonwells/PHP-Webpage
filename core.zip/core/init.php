<?php
///ob_start() will turn the webpage into a buffer that can be correctly read. without it the html will load first and the php will fail at certain parts
//this is only a problem on a public server. You dont have to start of object on localhost..
ob_start();

session_start();
error_reporting(0);
require "database/connect.php";
require "functions/general.php";
require "functions/users.php";
$current_file = explode('/', $_SERVER['SCRIPT_NAME']);
$current_file = end($current_file);

if(logged_in() === true){
$session_user_id = $_SESSION["user_id"];
$user_data = user_data($session_user_id,"user_id","username","password","firstname","lastname","email","type","profile");
if(user_active($user_data["username"]) === false){
session_destroy();
header("Location: index.php");
exit();

}
}


$errors = array();
?>