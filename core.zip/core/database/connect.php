<?php

//This is a unique way to return errors
$connect_error = "Sorry, we're having connection issues. ";
mysql_connect("localhost","kwells2_root","theboss") or die ($connect_error);
mysql_select_db("kwells2_phplogin")or die ($connect_error);

?>